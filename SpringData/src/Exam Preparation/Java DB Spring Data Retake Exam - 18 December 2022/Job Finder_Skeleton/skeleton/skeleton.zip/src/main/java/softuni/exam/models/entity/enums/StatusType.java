package softuni.exam.models.entity.enums;

public enum StatusType {

    unemployed,
    employed,
    freelancer
}
