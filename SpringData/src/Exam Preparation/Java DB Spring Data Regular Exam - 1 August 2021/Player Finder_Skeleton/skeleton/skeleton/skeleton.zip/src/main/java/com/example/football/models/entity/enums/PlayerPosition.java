package com.example.football.models.entity.enums;

public enum PlayerPosition {

    ATT, MID, DEF
}
